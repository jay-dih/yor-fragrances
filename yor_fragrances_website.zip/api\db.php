<?php
// api/db.php
// Update these variables with your InfinityFree database credentials
$host = 'localhost';
$dbname = 'yor_fragrances';
$username = 'root'; // Change for InfinityFree
$password = '';     // Change for InfinityFree

header('Content-Type: application/json');
// Optional: CORS headers if needed
// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
// header("Access-Control-Allow-Headers: Content-Type");

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

// Function to handle reading JSON body from frontend fetch requests
function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}
?>
